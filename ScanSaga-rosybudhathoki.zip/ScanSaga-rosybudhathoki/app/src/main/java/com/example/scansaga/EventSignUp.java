package com.example.scansaga;

public class EventSignUp {
}
