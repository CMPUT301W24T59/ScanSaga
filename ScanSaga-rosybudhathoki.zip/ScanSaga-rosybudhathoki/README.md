#ScanSaga

This is just the beginning stage of the project, more informantion will be qaqdded to readme as we discuss and progress.

## Features

- Feature 1
- Feature 2
- Feature 3

## Installation

Instructions on how to install and set up your project.

## Usage

How to use your project, including examples.

## Contributing

List of all team members.

## License

Information about the license of your project.
